\glossarysection[\glossarytoctitle]{\glossarytitle}\glossarypreamble
\begin{theglossary}\glossaryheader
\glsgroupheading{C}\relax \glsresetentrylist %
\glossentry{conjunto_vazio}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{33}}}%
\glossentry{constante:dado:pacote:gramatura}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{constante:dado:pedido:peso}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{constante:dado:pedido:quantidade-pacotes}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimR 32}}}%
\glossentry{constante:dado:receita:rendimento}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{constante:dado:receita:rendimento-total}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30}}}%
\glossentry{constante:dado:receita:tempo-assamento}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{constante:dado:receita:tempo-mistura}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimR 32}}}%
\glossentry{constante:dado:receita:tempo-modelagem}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{constante:dado:rendimento-total}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{31}}}%
\glossentry{constante:fixa:tempo-turno}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29}\delimN 
		\setentrycounter[]{page}\glsnumberformat{32}}}%
\glossentry{constante:pre-processada:quantidade-pacotes}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29\delimR 31}}}%
\glossentry{constante:pre-processada:quantidade-pedidos}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29\delimR 32}}}%
\glossentry{constante:pre-processada:quantidade-receitas}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29\delimR 31}}}\glsgroupskip
\glsgroupheading{I}\relax \glsresetentrylist %
\glossentry{indice:pacotes}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29}\delimN 
		\setentrycounter[]{page}\glsnumberformat{31}}}%
\glossentry{indice:pedidos}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29}\delimN 
		\setentrycounter[]{page}\glsnumberformat{31\delimN 32}}}%
\glossentry{indice:receitas}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{29}\delimN 
		\setentrycounter[]{page}\glsnumberformat{31}}}\glsgroupskip
\glsgroupheading{V}\relax \glsresetentrylist %
\glossentry{variavel:auxiliar:peso-total-em-sobra}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{31\delimN 32}}}%
\glossentry{variavel:auxiliar:peso-total-pedidos-atendidos}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{30\delimN 31}}}%
\glossentry{variavel:auxiliar:peso-total-produzido}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{31\delimN 32}}}%
\glossentry{variavel:principal:deve-atender-pedido}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{31}}}%
\glossentry{variavel:principal:quantidade-porcoes-receita-a-produzir}{\glossaryentrynumbers{\relax 
		\setentrycounter[]{page}\glsnumberformat{31\delimN 32}}}%
\end{theglossary}\glossarypostamble
